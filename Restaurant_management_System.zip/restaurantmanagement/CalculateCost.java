
package restaurantmanagement;


public interface CalculateCost {
    public double totalcost();
}
