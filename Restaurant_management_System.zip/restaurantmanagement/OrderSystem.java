
package restaurantmanagement;

public interface OrderSystem {
    public void Order();
}
